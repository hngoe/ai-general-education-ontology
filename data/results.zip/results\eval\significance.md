# 显著性检验（逐文档配对）

> 配对单元=同一大纲；双侧检验；p 由配对 t 检验与 Wilcoxon 符号秩检验给出（多指标并列报告）。dz=Cohen's dz。* p<.05 ** p<.01 *** p<.001


## A vs B：概念 F1（逐文档配对，n≤19）
- **deepseek 概念F1 A vs B**：A/B 均值 0.594/0.577（Δ=+0.017，n=19），t=1.26 p_t=0.224，W p_w=0.248，dz=0.29
- **glm 概念F1 A vs B**：A/B 均值 0.601/0.567（Δ=+0.034，n=19），t=1.23 p_t=0.235，W p_w=0.275，dz=0.28
- **qwen 概念F1 A vs B**：A/B 均值 0.563/0.513（Δ=+0.050，n=19），t=2.71 p_t=0.014*，W p_w=0.014*，dz=0.62

## A vs B：is-a 关系 F1（仅取两端该文档均有可判定 gold 的配对）
- **deepseek is-a F1 A vs B**：A/B 均值 0.375/0.283（Δ=+0.093，n=19），t=1.76 p_t=0.096，W p_w=0.076，dz=0.40
- **glm is-a F1 A vs B**：A/B 均值 0.300/0.293（Δ=+0.007，n=19），t=0.20 p_t=0.844，W p_w=0.906，dz=0.05
- **qwen is-a F1 A vs B**：A/B 均值 0.301/0.192（Δ=+0.109，n=19），t=1.62 p_t=0.123，W p_w=0.078，dz=0.37

## Core vs Peripheral：分层 F1（同策略内逐文档配对）
- **deepseek-A Core vs Peripheral**：A/B 均值 0.880/0.651（Δ=+0.230，n=18），t=3.13 p_t=0.006**，W p_w=0.005**，dz=0.74
- **deepseek-B Core vs Peripheral**：A/B 均值 0.852/0.634（Δ=+0.218，n=18），t=3.00 p_t=0.008**，W p_w=0.003**，dz=0.71
- **glm-A Core vs Peripheral**：A/B 均值 0.879/0.635（Δ=+0.244，n=18），t=3.71 p_t=0.002**，W p_w=0.001**，dz=0.87
- **glm-B Core vs Peripheral**：A/B 均值 0.878/0.658（Δ=+0.220，n=18），t=3.05 p_t=0.007**，W p_w=0.007**，dz=0.72
- **qwen-A Core vs Peripheral**：A/B 均值 0.877/0.711（Δ=+0.166，n=18），t=2.88 p_t=0.010*，W p_w=0.017*，dz=0.68
- **qwen-B Core vs Peripheral**：A/B 均值 0.869/0.653（Δ=+0.216，n=18），t=3.75 p_t=0.002**，W p_w=0.002**，dz=0.88
