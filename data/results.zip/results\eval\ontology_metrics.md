# 本体结构评估（GS 骨架版 ai_general_education.owl）

> 公式与口径：H=有向 subClassOf 边总数（131 概念→中层 + 10 中层→顶层 + is-a 50）；N=非层次对象属性断言（part-of 34 / prerequisite 9 / applied-in 12 / based-on 4 / operates-on 1 / overlapping 4）；RR=N/(H+N)；IR 平均直接子类数；AvgDepth=命名类沿 subClassOf 最长链至 owl:Thing 边数。

## 1. 规模与结构
- 命名类：147（顶层 6 / 中层 10 / GS 概念 131）；equivalentClass 对：4
- H=191，N=64
- **RR** = 0.251（替代口径：仅 is-a 概念边 H=50 时 RR=0.561）
- **IR**（父类平均）=4.78；IR（全部命名类平均）=1.30
- **AvgDepth**（全命名类）=3.46；末端类（无子类）均值=3.60（max=7，末端类 107 个）

## 2. Coverage
- (a) GS→本体骨架：131/131 = 1.000（骨架按构造收录全部 GS，属参考基线，与 (b) 分列报告）
- (b) LLM 候选覆盖（|∪提取概念并入槽位|/131，无需重跑）：
  - deepseek-A：Coverage=0.557（Core 16/17=0.941，Common 15/17=0.882，Peripheral 42/97=0.433）
  - deepseek-B：Coverage=0.580（Core 16/17=0.941，Common 15/17=0.882，Peripheral 45/97=0.464）
  - glm-A：Coverage=0.527（Core 16/17=0.941，Common 15/17=0.882，Peripheral 38/97=0.392）
  - glm-B：Coverage=0.573（Core 16/17=0.941，Common 15/17=0.882，Peripheral 44/97=0.454）
  - qwen-A：Coverage=0.588（Core 16/17=0.941，Common 15/17=0.882，Peripheral 46/97=0.474）
  - qwen-B：Coverage=0.626（Core 16/17=0.941，Common 15/17=0.882，Peripheral 51/97=0.526）

  最优候选覆盖：qwen-B = 0.626

## 3. 语料锚定双口径 Coverage（分母：全量 GS=131 vs 语料锚定=93）
| 模型-策略 | 全量 131 | 语料锚定 93 | 锚定层补充说明（0 命中政策/框架级概念不计入） |
|---|---|---|---|
| deepseek-A | 0.557 | 0.785 | 另命中 0 命中级 0 条（如政策/框架语词） |
| deepseek-B | 0.580 | 0.806 | 另命中 0 命中级 1 条（如政策/框架语词） |
| glm-A | 0.527 | 0.742 | 另命中 0 命中级 0 条（如政策/框架语词） |
| glm-B | 0.573 | 0.796 | 另命中 0 命中级 1 条（如政策/框架语词） |
| qwen-A | 0.588 | 0.806 | 另命中 0 命中级 2 条（如政策/框架语词） |
| qwen-B | 0.626 | 0.828 | 另命中 0 命中级 5 条（如政策/框架语词） |
