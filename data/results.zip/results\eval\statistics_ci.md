# 统计补强：bootstrap 95%CI / 配对差 / 效应量 / Holm 校正

> bootstrap n=20000（种子 42）；配对单元=同一文档（n≤19）；双侧；按族做 Holm 校正：F1 概念 A vs B（3 模型）、F2 is-a A vs B（3 模型）、F3 Core vs Peripheral（6 组合）。


## F1 概念 A vs B（每模型）
- deepseek：A=0.594 B=0.577（Δ95%CI=[-0.008,+0.044]），p_t=0.2241（Holm p=0.4482），Wilcoxon p=0.2485，dz=0.29，n=19
- glm：A=0.601 B=0.567（Δ95%CI=[-0.014,+0.091]），p_t=0.2345（Holm p=0.4482），Wilcoxon p=0.2753，dz=0.28，n=19
- qwen：A=0.563 B=0.513（Δ95%CI=[+0.016,+0.086]），p_t=0.0144（Holm p=0.0433），Wilcoxon p=0.0141，dz=0.62，n=19

## F2 is-a F1 A vs B
- deepseek：A=0.375 B=0.283（Δ95%CI=[-0.007,+0.192]），p_t=0.0960（Holm p=0.2879），Wilcoxon p=0.0759，dz=0.40，n=19
- glm：A=0.300 B=0.293（Δ95%CI=[-0.058,+0.072]），p_t=0.8443（Holm p=0.8443），Wilcoxon p=0.9058，dz=0.05，n=19
- qwen：A=0.301 B=0.192（Δ95%CI=[-0.014,+0.243]），p_t=0.1231（Holm p=0.2879），Wilcoxon p=0.0782，dz=0.37，n=19

## F3 Core vs Peripheral（同策略内）
- deepseek-A：Core=0.880 Per=0.651（Δ95%CI=[+0.102,+0.379]），p_t=0.0061（Holm p=0.0244），Wilcoxon p=0.0048，dz=0.74，n=18
- deepseek-B：Core=0.852 Per=0.634（Δ95%CI=[+0.092,+0.370]），p_t=0.0080（Holm p=0.0244），Wilcoxon p=0.0031，dz=0.71，n=18
- glm-A：Core=0.879 Per=0.635（Δ95%CI=[+0.126,+0.376]），p_t=0.0017（Holm p=0.0096），Wilcoxon p=0.0011，dz=0.87，n=18
- glm-B：Core=0.878 Per=0.658（Δ95%CI=[+0.092,+0.366]），p_t=0.0072（Holm p=0.0244），Wilcoxon p=0.0072，dz=0.72，n=18
- qwen-A：Core=0.877 Per=0.711（Δ95%CI=[+0.060,+0.280]），p_t=0.0104（Holm p=0.0244），Wilcoxon p=0.0174，dz=0.68，n=18
- qwen-B：Core=0.869 Per=0.653（Δ95%CI=[+0.109,+0.329]），p_t=0.0016（Holm p=0.0096），Wilcoxon p=0.0021，dz=0.88，n=18

> 解读建议：F1 中 Qwen A>B 在 Holm 校正后仍显著则强结论；F3 全组合显著。报告时给 Δ95%CI 与 dz，p 注明未校正/Holm 两列，避免多重比较质疑。
