# 关系抽取重分析（语料级 union 口径）

> gold 主干 = 75 条（is-a 37 / part-of 18 / prerequisite 8 / applied-in 12）。

> 可恢复口径 = 60 条（两端概念至少在语料中出现一次）。


## deepseek / 策略 A

- 预测关系总数：760；out-of-backbone（端点未命中 GS）：424（55.8%）
- **A. typed union recall**：全 75 主干 = 0.373；可恢复 60 条 = 0.467
  - is-a 0.541  part-of 0.222  prerequisite 0.375  applied-in 0.083
- **B. 粒度折叠（is-a 祖先投影）后 typed union recall**：全 75 = 0.427；可恢复 = 0.500
- **C. 三层阶梯 recall**：L1 端点对(无向,忽略类型)=0.431 → L2 端点对+方向(忽略类型)=0.400 → L3 端点对+方向+类型=0.373
  - 方向损失 L1→L2 = 0.031；类型混淆损失 L2→L3 = 0.027

## deepseek / 策略 B

- 预测关系总数：1219；out-of-backbone（端点未命中 GS）：683（56.0%）
- **A. typed union recall**：全 75 主干 = 0.320；可恢复 60 条 = 0.400
  - is-a 0.486  part-of 0.111  prerequisite 0.500  applied-in 0.000
- **B. 粒度折叠（is-a 祖先投影）后 typed union recall**：全 75 = 0.373；可恢复 = 0.433
- **C. 三层阶梯 recall**：L1 端点对(无向,忽略类型)=0.500 → L2 端点对+方向(忽略类型)=0.400 → L3 端点对+方向+类型=0.320
  - 方向损失 L1→L2 = 0.100；类型混淆损失 L2→L3 = 0.080

## glm / 策略 A

- 预测关系总数：709；out-of-backbone（端点未命中 GS）：378（53.3%）
- **A. typed union recall**：全 75 主干 = 0.333；可恢复 60 条 = 0.417
  - is-a 0.514  part-of 0.056  prerequisite 0.250  applied-in 0.250
- **B. 粒度折叠（is-a 祖先投影）后 typed union recall**：全 75 = 0.373；可恢复 = 0.433
- **C. 三层阶梯 recall**：L1 端点对(无向,忽略类型)=0.417 → L2 端点对+方向(忽略类型)=0.400 → L3 端点对+方向+类型=0.333
  - 方向损失 L1→L2 = 0.017；类型混淆损失 L2→L3 = 0.067

## glm / 策略 B

- 预测关系总数：1833；out-of-backbone（端点未命中 GS）：1163（63.4%）
- **A. typed union recall**：全 75 主干 = 0.373；可恢复 60 条 = 0.467
  - is-a 0.541  part-of 0.111  prerequisite 0.500  applied-in 0.167
- **B. 粒度折叠（is-a 祖先投影）后 typed union recall**：全 75 = 0.413；可恢复 = 0.483
- **C. 三层阶梯 recall**：L1 端点对(无向,忽略类型)=0.444 → L2 端点对+方向(忽略类型)=0.440 → L3 端点对+方向+类型=0.373
  - 方向损失 L1→L2 = 0.004；类型混淆损失 L2→L3 = 0.067

## qwen / 策略 A

- 预测关系总数：776；out-of-backbone（端点未命中 GS）：428（55.2%）
- **A. typed union recall**：全 75 主干 = 0.347；可恢复 60 条 = 0.417
  - is-a 0.432  part-of 0.222  prerequisite 0.500  applied-in 0.167
- **B. 粒度折叠（is-a 祖先投影）后 typed union recall**：全 75 = 0.413；可恢复 = 0.467
- **C. 三层阶梯 recall**：L1 端点对(无向,忽略类型)=0.486 → L2 端点对+方向(忽略类型)=0.427 → L3 端点对+方向+类型=0.347
  - 方向损失 L1→L2 = 0.059；类型混淆损失 L2→L3 = 0.080

## qwen / 策略 B

- 预测关系总数：1677；out-of-backbone（端点未命中 GS）：1048（62.5%）
- **A. typed union recall**：全 75 主干 = 0.347；可恢复 60 条 = 0.433
  - is-a 0.486  part-of 0.222  prerequisite 0.500  applied-in 0.000
- **B. 粒度折叠（is-a 祖先投影）后 typed union recall**：全 75 = 0.387；可恢复 = 0.450
- **C. 三层阶梯 recall**：L1 端点对(无向,忽略类型)=0.458 → L2 端点对+方向(忽略类型)=0.440 → L3 端点对+方向+类型=0.347
  - 方向损失 L1→L2 = 0.018；类型混淆损失 L2→L3 = 0.093
