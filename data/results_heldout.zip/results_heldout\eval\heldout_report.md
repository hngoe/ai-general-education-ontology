# Held-out 独立集评测（人工文档级 gold）

> gold 来自 `data/held_out/heldout_gold_concepts.csv`（人工标注 present 概念），**不再**使用 `anchor_slots` 子串匹配。旧 19 份同源结果为 in-corpus reference。

## deepseek / 策略A

- 概念（文档级宏平均）：P=0.384 R=0.683 F1=0.477
- 分层 R：Core 0.886  Common 0.693  Peripheral 0.455
- 开放集新概念召回：0.598（参与文档 14）
## deepseek / 策略B

- 概念（文档级宏平均）：P=0.384 R=0.665 F1=0.476
- 分层 R：Core 0.856  Common 0.670  Peripheral 0.463
- 开放集新概念召回：0.583（参与文档 14）
## glm / 策略A

- 概念（文档级宏平均）：P=0.411 R=0.655 F1=0.481
- 分层 R：Core 0.863  Common 0.690  Peripheral 0.427
- 开放集新概念召回：0.526（参与文档 14）
## glm / 策略B

- 概念（文档级宏平均）：P=0.329 R=0.671 F1=0.428
- 分层 R：Core 0.884  Common 0.717  Peripheral 0.416
- 开放集新概念召回：0.571（参与文档 14）
## qwen / 策略A

- 概念（文档级宏平均）：P=0.323 R=0.685 F1=0.424
- 分层 R：Core 0.882  Common 0.676  Peripheral 0.479
- 开放集新概念召回：0.579（参与文档 14）
## qwen / 策略B

- 概念（文档级宏平均）：P=0.341 R=0.722 F1=0.446
- 分层 R：Core 0.874  Common 0.759  Peripheral 0.526
- 开放集新概念召回：0.579（参与文档 14）
